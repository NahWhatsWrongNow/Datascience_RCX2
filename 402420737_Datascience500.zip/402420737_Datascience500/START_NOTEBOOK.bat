@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run SETUP_WINDOWS.bat before starting the notebook.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python -m jupyter lab "Book_Market_Analytics.ipynb"
if errorlevel 1 pause
