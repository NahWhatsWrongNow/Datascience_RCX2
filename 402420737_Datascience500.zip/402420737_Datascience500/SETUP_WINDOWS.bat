@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% -m venv .venv
if errorlevel 1 goto error
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto error
echo.
echo Setup complete. Run START_NOTEBOOK.bat next.
pause
exit /b 0
:error
echo Python setup failed. Check that Python 3.10+ and Internet access are available.
pause
exit /b 1
